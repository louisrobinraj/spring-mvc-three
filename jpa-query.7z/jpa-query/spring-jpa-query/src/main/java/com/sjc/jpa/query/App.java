package com.sjc.jpa.query;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeDaoImpl dao = (EmployeeDaoImpl) context.getBean("employeeDao");

		dao.test();
		context.close();

	}
}
