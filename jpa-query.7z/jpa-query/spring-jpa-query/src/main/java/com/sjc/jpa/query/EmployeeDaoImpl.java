package com.sjc.jpa.query;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.metamodel.EntityType;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public class EmployeeDaoImpl {
	public void test() {
		prepareData();
		List<Employee> l = em.createQuery("SELECT e FROM Employee e").getResultList();
		for (Employee p : l) {
			System.out.println(p);
		}
	}

	private void prepareData() {
		Employee employee1 = new Employee();
		employee1.setName("Arun");
		employee1.setStartDate(new Date());
		employee1.setSalary(12000);

		Employee employee2 = new Employee();
		employee2.setName("Surendhar");
		employee2.setStartDate(new Date());
		employee2.setSalary(10000);

		Employee employee3 = new Employee();
		employee3.setName("Liyo");
		employee3.setStartDate(new Date());
		employee3.setSalary(10100);

		Department department1 = new Department();
		department1.setName("ADM 1");

		Department department2 = new Department();
		department2.setName("ADM 2");

		Address address = new Address();
		address.setStreet("Medavilagam");
		address.setCity("Kollamcode");
		address.setState("Tamil nadu");
		address.setZip("629160");

		employee1.setAddress(address);
		employee1.setDepartment(department1);
		employee1.setManager(employee1);

		employee2.setAddress(address);
		employee2.setDepartment(department1);
		employee2.setManager(employee1);

		employee3.setAddress(address);
		employee3.setDepartment(department1);
		employee3.setManager(employee1);

		Project project1 = new Project();
		project1.setName("ABS");
		
		Project project2 = new Project();
		project2.setName("PASS");
		Project project3 = new Project();
		project3.setName("One Web");

		Collection<Project> projects = new ArrayList<Project>();
		projects.add(project1);
		projects.add(project2);
		projects.add(project3);

		employee1.setProjects(projects);

		Phone phone1 = new Phone();
		phone1.setNumber("1234");
		phone1.setEmployee(employee1);

		Phone phone2 = new Phone();
		phone2.setNumber("1234");
		phone2.setEmployee(employee1);

		Collection<Phone> phones = new ArrayList<Phone>();
		phones.add(phone2);
		phones.add(phone2);

		employee1.setPhones(phones);

		//Many to Many test
		
		Collection<Employee> employeeList=new ArrayList<>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);
		project1.setEmployees(employeeList);
		
		em.persist(employee1);
		em.persist(employee2);
		em.persist(employee3);

	}

	@PersistenceContext
	private EntityManager em;
}
