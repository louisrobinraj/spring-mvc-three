package com.sjc.jpa.query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private long salary;
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@OneToOne(cascade = CascadeType.ALL)
	private Address address;

	@ManyToOne(cascade = CascadeType.ALL)
	private Department department;

	@ManyToOne(cascade = CascadeType.ALL) // using self join
	private Employee manager;

	@OneToMany(mappedBy = "manager", targetEntity = Employee.class,cascade = CascadeType.ALL)
	private Collection<Employee> directs = new ArrayList<Employee>();

	@OneToMany(mappedBy = "employee", targetEntity = Phone.class,cascade = CascadeType.ALL)
	private Collection<Phone> phones = new ArrayList<Phone>();
	
	@ManyToMany(mappedBy = "employees", targetEntity = Project.class,cascade = CascadeType.ALL)
	private Collection<Project> projects = new ArrayList<Project>();


	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public long getSalary() {
		return salary;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Address getAddress() {
		return address;
	}

	public Department getDepartment() {
		return department;
	}

	public Employee getManager() {
		return manager;
	}

	public Collection<Employee> getDirects() {
		return directs;
	}

	public Collection<Project> getProjects() {
		return projects;
	}

	public Collection<Phone> getPhones() {
		return phones;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}

	public void setDirects(Collection<Employee> directs) {
		this.directs = directs;
	}

	public void setProjects(Collection<Project> projects) {
		this.projects = projects;
	}

	public void setPhones(Collection<Phone> phones) {
		this.phones = phones;
	}

	public String toString() {
		return "Employee " + getId() + ": name: " + getName() + ", salary: " + getSalary() + ", phones: " + getPhones()
				+ ", managerNo: " + ((getManager() == null) ? null : getManager().getId()) + ", deptNo: "
				+ ((getDepartment() == null) ? null : getDepartment().getId());
	}

}